'use strict';

App.defineClass('Gigamart.enums.VideoType', function VideoType () {

	return {
		FHD: 'fhd',
		HD: 'hd',
		UHD: 'uhd'
	};
});
