'use strict';

App.defineClass('Gigamart.enums.ViewMode', function ViewMode () {

	return {
		LIST: 'list',
		PLAYER: 'player'
	};
});