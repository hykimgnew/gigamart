'use strict';

function testFunction() {
	var testvar = 4;
	return testvar;
}