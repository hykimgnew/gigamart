'use strict';

/**
 *  Category Js : Main
 **/
var global = window;

//*************************************************
// * 넘어온 전체카테고리, 상세카테고리 코드 (포커스 보전용)
//*************************************************
var requestCategoryCode     = request.getParameter("categoryCode");
var requestCategoryDtlCode  = request.getParameter("categoryDtlCode");
var requestCategoryDtlPage  = request.getParameter("categoryDtlPage");

//*************************************************
// * Popup
// * isCart       : 간편 장바구니
//*************************************************
 var isCart = false;

//*************************************************
// *  간편 장바구니 팝업
// * cartHtml = 장바구니 HTML
// * cartFocus = 장바구니 Focus 값
//*************************************************
var cartHtml = "";
var cartFocus = 0;

//*************************************************
// *  쇼퍼 주문 이력 팝업
// * histHtml                     = 쇼퍼 주문 이력 HTML
// * histFocus                    = 쇼퍼 주문 이력 Focus 값
// *  0 : 선택 안됐을 때
// *  1 : 주문 이력
// *  2 : 쇼퍼 리얼 타임 버튼
// *  3 : 닫기
// * histPage                     = 주문 이력 페이지
// * currentOrderedProductPage    = 구매 상품 리스트 현재 페이지 (default : 0)
// * totalOrderedPage             = 구매 상품 리스트 전체 페이지
// * maxOrderedPage               = 구매 상품 리스트 한 페이지에 표시할 최대 상품 수 (default : 5)
// * productList                  = 구매 상품 리스트 배열
//*************************************************
var histHtml = "";
var histFocus = 0;
var histPage = 1;

var currentOrderedProductPage = 0;
var totalOrderedPage          = 0;
var maxOrderedPageView        = 5;
var productList               = new Array();

/** 
 *  현재 리스트 Focus 위치
 *  0 : 카테고리
 *  1 : 상세 카테고리
 *  2 : 쇼퍼's bag
 *  3 : 쇼퍼 주문 이력
 **/
var currentFocusList = 0;

/** 
 *  현재 카테고리 Focus 위치
 *  0 : 사람 모양
 *  1 : 음성 인식
 *  2 : 동그란 사람 얼굴
 *  3 : 쇼퍼's Bag
 *  4 : 과일... 
 **/    
var currentFocusMenu = 4;

/**
 * 현재 상세카테고리 Focus 위치
 * 0 : 사과/배
 * 1 : 참외/토마토...
 **/
var currentFocusDtl = 0;

/** 
 * 현재 상세카테고리의 페이지
 * 0 : 1페이지
 * 1 : 2페이지... (차후에는 페이징 모듈 필요함)
 **/
var currentFocusDtlPage = 0;

/**
 * 이전/다음 페이지 true /false
 *  true일 경우 전/다음 페이지 있음
 **/
 var prevPageYN = false;
 var nextPageYN = false;


/***********************************
 * CMS API 조회 데이터 
 ***********************************/
var shopperHistoryContent = ""; // 쇼퍼 주문 이력


/** video object 재생 클래스, 해당 클래스의 인스턴스를 만들어 video 재생을 함.*/
var videoPlayerClass = function (videoPath, elementId, pId) {
    this.Path = videoPath;
    this.Id = elementId;
    var positionId = pId;

    this.videoPlayer = null;
    this.playerPositionCall = new cycleClass();

    var timerPlayer = null;
    var videoType = "video/mpeg";
    //var videoType = "video/broadcast";

    //if (elementId == 'sub_mpeg_player' || elementId == 'oneToone_left_player') {
    //    videoType = "video/broadcast";
    //}

    /** video 인스턴스 초기화.*/
    this.init = function () {
        try {
            if (window.oipfObjectFactory.isObjectSupported(videoType)) {
                this.videoPlayer = document.getElementById(this.Id);
                console.log("======== video player create id : " + this.Id);
                this.videoPlayer.data = this.Path;
                timerPlayer = this.videoPlayer;
            } else {
                document.write("<p>비디오 사용 실패</p>");
                console.log("비디오 사용 실패");
            }
        } catch (err) {
            alert("init fail : " + err);
        }
    };
    this.init();

    /** video 재생 시작.*/
    this.videoObjectPlay = function () {
        try {
            console.log("======== videoObjectPlay function() " + this.Id + " video player playState : " + this.videoPlayer.playState);
            if (typeof this.videoPlayer.playState != 'undefined') {
                if (this.videoPlayer.playState == 0 || this.videoPlayer.playState == 2) {
                    this.videoPlayer.play(1);
                    console.log("======== start video player id : " + this.Id);
                }
            }
        } catch (err) {
            //alert("Video play " + err);
            console.log("Video play " + err);
        }
    };

    /** video 멈춤.*/
    this.videoObjectStop = function () {
        console.log("======== videoObjectStop function() " + this.Id + " video player playState : " + this.videoPlayer.playState);
        try {
            if (typeof this.videoPlayer.playState != 'undefined') {
                if (this.videoPlayer.playState != 0) {
                    this.videoPlayer.stop();
                    console.log("======== stop video player id : " + this.Id);
                }
            }
        } catch (err) {
            //alert("Video stop " + err);
            console.log("Video stop " + err);
        }
    };

    /** video 일시 정지.*/
    this.videoObjectPause = function () {
        this.videoPlayer.play(0);
    };

    /** video 재생 콘텐츠 경로.*/
    /*this.setVideoPlayerData = function (path) {
        this.videoPlayer.data = path;
    }*/

    /** video 재생 콘텐츠 경로.*/
    this.getVideoPlayerData = function () {
        return this.videoPlayer.data;
    }

    /** video player 상태.*/
    this.getVideoStatus = function () {
        return this.videoPlayer.playState;
    }

    /** video player error.*/
    this.getVideoError = function () {
        return this.videoPlayer.error;
    }

    /** 재생되는 현재 시간을 출력하는 html 태그 아이디 설정 */
    /*this.setVideoPlayerPositionID = function (id) {
        positionId = id;
    }*/

    /** video player 재생 시간 display.*/
    this.playerPosition = function () {
        try {
            if (timerPlayer.readyToPlay) {
                //alert(this.videoPlayer.playPosition);
                var d = new Date(timerPlayer.playPosition);
                var HH = "";
                var MM = "";
                var SS = "";

                if (d.getHours() < 10) {
                    HH = "0" + d.getUTCHours();
                } else {
                    HH = d.getUTCHours();
                }
                if (d.getMinutes() < 10) {
                    MM = "0" + d.getUTCMinutes();
                } else {
                    MM = d.getUTCMinutes();
                }
                if (d.getSeconds() < 10) {
                    SS = "0" + d.getUTCSeconds();
                } else {
                    SS = d.getUTCSeconds();
                }

                var currentTime = HH + ":" + MM + ":" + SS;
                //if(this.videoPlayer.readyToPlay){}
                document.getElementById(positionId).textContent = currentTime;
            }
        } catch (err) {
            alert(err);
        }
    };

    /** 런타임 시간 가운터 플레이어 우측 상단에서 카운터 됨.*/
    this.playerPositionView = function (onoff, elementId) {
        try {
            if (onoff) {
                this.playerPositionCall.cycleCallStart(1000, this.playerPosition(elementId));
            } else {
                this.playerPositionCall.cycleCallStop();
                document.getElementById(elementId).textContent = "";
            }
        } catch (err) {
            alert(err);
        }
    };
};

/** timer class */
var TimerClass = function () {
    this.Interval = 1000;
    this.Enable = new Boolean(false);
    this.Tick;
    var timerId = 0;
    var thisObject;
    this.Start = function () {
        this.Enable = new Boolean(true);

        thisObject = this;
        if (thisObject.Enable) {
            thisObject.timerId = setInterval(
            function () {
                thisObject.Tick();
            }, thisObject.Interval);
        }
    };
    this.Stop = function () {
        thisObject.Enable = new Boolean(false);
        clearInterval(thisObject.timerId);
    };
};
var cycleClass = function () {
    var timer = new TimerClass();

    this.cycleCallStart = function (msec, callFunction) {
        try {
            timer.Interval = msec;
            timer.Tick = callFunction;
            timer.Start();
        } catch (err) {
            alert(err);
        }
    };
    this.cycleCallStop = function () {
        try {
            timer.Stop();
        } catch (err) {
            alert(err);
        }
    };
};

global.onload = function() {
    global.Category = Gigamart.app.category.Category.create();
    global.Category.init();
};
App.defineClass('Gigamart.app.category.Category', {
    _construct: function() {
        var me = this,
            viewMode = Gigamart.enums.ViewMode.LIST;

      me.__defineGetter__('viewMode', function () {
            return viewMode;
      });

      EventBus.register(me, 'changeViewMode', function (targetViewMode, movieDatum) {
            viewMode = targetViewMode;
            EventBus.fire('completeToChangeViewMode', movieDatum);
      });

    },
    init: function() {
        $('li[name="category_menu"]').eq(currentFocusMenu).addClass("focus");

        var me = this;
        global.stbService = Gigamart.app.category.STBService.create(EventBus);

    }
        
       
});